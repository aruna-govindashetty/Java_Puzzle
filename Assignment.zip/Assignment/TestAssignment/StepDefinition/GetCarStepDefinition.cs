﻿
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using TechTalk.SpecFlow;
using TestAssignment.Helper;

namespace TestAssignment.StepDefinition
{
    [Binding]
    public sealed class GetCarStepDefinition
    {
        [Given(@"I have a manufacturer details")]
        public void GivenIHaveAManufacturerDetails()
        {
            ScenarioContext.Current.Pending();
        }

        [Given(@"I have a manufacturer name (.*)")]
        public void GivenIHaveAManufacturerName(string manufacturerName)
        {
            ScenarioContextWrapper.SetContextObject("ManufacturerName", manufacturerName);
        }

        [Given(@"I have a manufacturer name (.*) and the model name (.*)")]
        public void GivenIHaveAManufacturerNameAndTheModelName(string manufacturerName, string modelName)
        {
            ScenarioContextWrapper.SetContextObject("ManufacturerName", manufacturerName);
            ScenarioContextWrapper.SetContextObject("ModelName", modelName);
        }

        [When(@"I make a request to get all details")]
        public void WhenIMakeARequestToGetAllDetails()
        {
            var restRequest = BuildApiRequest.BuildGetAll(ConfigurationManager.AppSettings.Get("wa_key"));
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, ConfigurationManager.AppSettings.Get("appUrl"));
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("statusCode", (int)statusCode);
        }

        [When(@"I make a request to get car models based on manufacturer name (.*) ")]
        public void WhenIMakeARequestToGetCarModelsBasedOnManufacturerName(string manufacturerName)
        {
            manufacturerName = ScenarioContextWrapper.GetContextObject<string>("ManufacturerName");
            var restRequest = BuildApiRequest.BuildGetModelByManufacturer(manufacturerName, ConfigurationManager.AppSettings.Get("wa_key"));
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, ConfigurationManager.AppSettings.Get("appUrl"));
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("statusCode", (int)statusCode);
        }

        [When(@"I make a request to get car build date based on manufacturer name (.*) and model name (.*)")]
        public void WhenIMakeARequestToGetCarBuildDateBasedOnManufacturerNameAstonMartinAndModelNameDBS(string manufacturerName,string modelName)
        {
            manufacturerName = ScenarioContextWrapper.GetContextObject<string>("ManufacturerName");
            modelName = ScenarioContextWrapper.GetContextObject<string>("ModelName");
            var restRequest = BuildApiRequest.BuildGetBuildDateByModelAndManufacturerName(manufacturerName,modelName,ConfigurationManager.AppSettings.Get("wa_key"));
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, ConfigurationManager.AppSettings.Get("appUrl"));
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("statusCode", (int)statusCode);
            ScenarioContextWrapper.SetContextObject("response", restResponse);

        }

        [Then(@"The list of details if available should be retrieved with (.*) response code")]
        public void ThenTheListOfDetailsIfAvailableShouldBeRetrievedWithResponseCode(int responseCode)
        {
            string responseString= ScenarioContextWrapper.GetContextObject<string>("response");
            dynamic jsonObject = JObject.Parse(responseString);
            int status = (int)jsonObject.Status;
            Assert.Equals(0, status);
            
            //alternative
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("statusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }

        [Then(@"The list of car models if available should be retrieved with (.*) response code")]
        public void ThenTheListOfCarModelsIfAvailableShouldBeRetrievedWithResponseCode(int responseCode)
        {
            //JObject to verify the response content
            string returnedJson = ScenarioContextWrapper.GetContextObject<string>("response");
            dynamic api = JObject.Parse(returnedJson);
            var wkda = api.wkda;
            var key1 = api.wkda[0].value1;

            
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("statusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }

        [Then(@"The car build date if available should be retrieved with (.*) response code")]
        public void ThenTheCarBuildDateIfAvailableShouldBeRetrievedWithResponseCode(int responseCode)
        {
            var responseCodeFromApi = ScenarioContextWrapper.GetContextObject<int>("statusCode");
            Assert.AreEqual(responseCode, responseCodeFromApi);
        }































        [Given(@"I have a manufacturer name (.*),model name (.*) and the builddate (.*)")]
        public void GivenIHaveAManufacturerNameModelNameAndTheBuilddate(string manufacturerName,string modelName,string buildDate)
        {
            ScenarioContextWrapper.SetContextObject("ManufacturerName", manufacturerName);
            ScenarioContextWrapper.SetContextObject("ModelName", modelName);
            ScenarioContextWrapper.SetContextObject("BuildDate", buildDate);
        }

        [When(@"I make a request to get cars based on manufacturer name (.*)")]
        public void WhenIMakeARequestToGetCarsBasedOnManufacturerName(string manufacturerName)
        {
            manufacturerName = ScenarioContextWrapper.GetContextObject<string>("ManufacturerName");
            
        }

        [When(@"I make a request to get cars based on manufacturer name (.*) and the model name (.*)")]
        public void WhenIMakeARequestToGetCarsBasedOnManufacturerNameAndTheModelName(string manufacturerName, string modelName)
        {
            
        }

        [When(@"I make a request to get cars based on manufacturer name (.*),model name(.*) and build date(.*)")]
        public void WhenIMakeARequestToGetCarsBasedOnManufacturerNameModelNameAndBuildDate(string manufacturerName, string modelName, string buildDate)
        {
            manufacturerName = ScenarioContextWrapper.GetContextObject<string>("ManufacturerName");
            modelName = ScenarioContextWrapper.GetContextObject<string>("ModelName");
            buildDate= ScenarioContextWrapper.GetContextObject<string>("BuildDate");
            var restRequest = BuildApiRequest.BuildGetBuildDate(manufacturerName,modelName,buildDate, ConfigurationManager.AppSettings.Get("wa_key"));
            var restResponse = ExecuteApi.ExecuteTheApi(restRequest, ConfigurationManager.AppSettings.Get("appUrl"));
            HttpStatusCode statusCode = restResponse.StatusCode;
            ScenarioContextWrapper.SetContextObject("statusCode", (int)statusCode);
        }

        [Then(@"The list of car's if available should be retrieved with (.*) response code")]
        public void ThenTheListOfCarSIfAvailableShouldBeRetrievedWithResponseCode(int responseCode)
        {
            
        }
    }
}
