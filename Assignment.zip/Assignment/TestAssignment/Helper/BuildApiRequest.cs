﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace TestAssignment.Helper
{
    public class BuildApiRequest
    {
        public static RestRequest BuildGetAll(string wa_key)
        {
            var restRequest = new RestRequest
            {
                Method = Method.GET,
                Resource = string.Format("/v1/cartypes/manufacturer"),
                RequestFormat = DataFormat.Json
            };
            restRequest.AddHeader(ConfigurationManager.AppSettings.Get("HeaderParameter"), wa_key);
            return restRequest;
        }

        public static RestRequest BuildGetModelByManufacturer(string manufacturerName, string wa_key)
        {
            var restRequest = new RestRequest
            {
                Method = Method.GET,
                Resource = string.Format("/v1/cartypes/maintypes/{0}", manufacturerName),
                RequestFormat = DataFormat.Json
            };
            restRequest.AddHeader(ConfigurationManager.AppSettings.Get("HeaderParameter"), wa_key);
            return restRequest;
        }

        public static RestRequest BuildGetBuildDateByModelAndManufacturerName(string manufacturerName,string modelName,string wa_key)
        {
            var restRequest = new RestRequest
            {
                Method = Method.GET,
                Resource = string.Format("/v1/cartypes/builtdates/{0}/{1}", manufacturerName, modelName),
                RequestFormat = DataFormat.Json
            };
            restRequest.AddHeader(ConfigurationManager.AppSettings.Get("HeaderParameter"), wa_key);
            return restRequest;
        }

        public static RestRequest BuildGetBuildDateByModel(string modelName, string wa_key)
        {
            var restRequest = new RestRequest
            {
                Method = Method.GET,
                Resource = string.Format("/v1/cartypes/builtdates/{0}", modelName),
                RequestFormat = DataFormat.Json
            };
            restRequest.AddHeader(ConfigurationManager.AppSettings.Get("HeaderParameter"), wa_key);
            return restRequest;
        }
    }
}
        
    



