﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAssignment.Helper
{
    public class ExecuteApi
    {
        public static RestResponse ExecuteTheApi(RestRequest restRequest,string appUrl)
        {
            var restClient = new RestClient(appUrl);
            Console.WriteLine($"Sending the following request to '{appUrl}' -");
            Console.WriteLine(JsonConvert.SerializeObject(restRequest, new JsonSerializerSettings { Formatting = Formatting.Indented, ReferenceLoopHandling = ReferenceLoopHandling.Ignore }));
            var response = restClient.Execute(restRequest);
            Console.WriteLine($"Received the following response from '{appUrl}' -");
            Console.WriteLine(JsonConvert.SerializeObject(response, new JsonSerializerSettings { Formatting = Formatting.Indented, ReferenceLoopHandling = ReferenceLoopHandling.Ignore }));
            return (RestResponse)response;
        }
    }
}
